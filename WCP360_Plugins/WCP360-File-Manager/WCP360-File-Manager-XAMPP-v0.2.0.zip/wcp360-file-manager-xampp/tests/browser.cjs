// Run with Node and Playwright installed in the test environment. Test data never touches an existing install.
const fs=require('fs'),path=require('path'),cp=require('child_process'),assert=require('assert');
const {chromium}=require(process.env.FM_PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const source=path.resolve(__dirname,'..'),tmp=fs.mkdtempSync('/tmp/fm-ui-');
 fs.cpSync(source,tmp,{recursive:true,filter:p=>!['vendor','var','.phpunit.cache'].includes(path.basename(p))});fs.symlinkSync(source+'/vendor',tmp+'/vendor');
 const root=tmp+'/standalone/var/files';fs.mkdirSync(root,{recursive:true});fs.mkdirSync(tmp+'/standalone/var/state');
 const hash=cp.execFileSync('php',['-r',"echo password_hash('browser-test-password', PASSWORD_DEFAULT);"]).toString();
 fs.writeFileSync(tmp+'/standalone/var/config.php',`<?php return ['APP_SECRET'=>'${require('crypto').randomBytes(32).toString('hex')}','FM_USERNAME'=>'tester','FM_PASSWORD_HASH'=>'${hash}','FM_ROOT'=>__DIR__.'/files','FM_STATE'=>__DIR__.'/state'];`);
 fs.mkdirSync(root+'/Documents');fs.mkdirSync(root+'/Destination');fs.mkdirSync(root+'/Documents/Sub');fs.writeFileSync(root+'/Documents/Sub/note.txt','hello');
 fs.writeFileSync(root+'/README.md','# Bienvenue\nVotre gestionnaire de fichiers.');fs.writeFileSync(root+'/second.txt','second');fs.writeFileSync(root+'/.env','APP=demo');
 const server=cp.spawn('php',['-S','127.0.0.1:8879','-t','standalone/public','standalone/public/index.php'],{cwd:tmp,stdio:'ignore'});let browser;const checks=[];
 try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1440,height:960}}),errors=[];page.setDefaultTimeout(10000);page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
 await page.goto('http://127.0.0.1:8879/login');await page.locator('[name=_username]').fill('tester');await page.locator('[name=_password]').fill('browser-test-password');await page.getByRole('button',{name:'Se connecter'}).click();
 const rows=page.locator('#rows'),row=name=>rows.locator('tr').filter({has:page.getByRole('button',{name,exact:true})});
 const open=name=>rows.getByRole('button',{name,exact:true}).click();
 const select=async name=>{await row(name).locator('input[type=checkbox]').check();};
 const until=async(fn)=>{const end=Date.now()+10000;while(!(await fn())){if(Date.now()>end)throw new Error('UI wait timed out');await new Promise(r=>setTimeout(r,25));}};
 const done=async()=>until(async()=>!(await page.locator('#newFile').isDisabled()));
 const home=async()=>{await page.locator('#breadcrumbs').getByRole('button',{name:'Mes fichiers',exact:true}).click();await row('README.md').waitFor();};
 await row('README.md').waitFor();await page.locator('#autoRefresh').uncheck();checks.push('login and list');
 assert.strictEqual(await row('.env').count(),0);await page.locator('#hiddenToggle').check();await row('.env').waitFor();checks.push('hidden files toggle');
 await page.locator('#tree').getByRole('button',{name:'Déplier ou replier Documents',exact:true}).click();await page.locator('#tree').getByRole('button',{name:'Sub',exact:true}).waitFor();checks.push('expand tree');
 await select('README.md');await select('second.txt');assert.match(await page.locator('#selectedCount').textContent(),/2 sélectionnés/);checks.push('multiple selection');
 await page.locator('#copyBtn').click();await open('Destination');await page.locator('#pasteBtn').click();await row('README.md').waitFor();await done();assert(fs.existsSync(root+'/Destination/second.txt'));checks.push('copy multiple via clipboard');
 await page.locator('#pasteBtn').click();await done();await until(async()=>(await page.locator('#operationSummary').textContent()).includes('2 échec'));assert.strictEqual(fs.readFileSync(root+'/Destination/second.txt','utf8'),'second');checks.push('conflicts preserve originals and report failures');
 await home();await select('Documents');await page.locator('#duplicateBtn').click();await row('Documents - copie').waitFor();await done();assert(fs.existsSync(root+'/Documents - copie/Sub/note.txt'));checks.push('recursive duplication');
 await select('Documents - copie');await page.locator('#trashBtn').click();await until(async()=>(await page.locator('#operationSummary').textContent()).startsWith('Corbeille'));await done();assert(!fs.existsSync(root+'/Documents - copie'));checks.push('trash nonempty folder');
 await page.locator('#trashNav').click();await row('Documents - copie').waitFor();await select('Documents - copie');await page.locator('#restoreBtn').click();await done();assert(fs.existsSync(root+'/Documents - copie/Sub/note.txt'));checks.push('restore nonempty folder');
 await page.locator('#filesNav').click();await row('README.md').waitFor();
 await row('second.txt').click({button:'right'});await page.locator('#contextMenu').getByRole('button',{name:'Renommer / déplacer',exact:true}).click();await page.locator('#promptValue').fill('renamed.txt');await page.locator('#promptForm').getByRole('button',{name:'Confirmer'}).click();await row('renamed.txt').waitFor();await done();checks.push('context menu rename');
 await select('renamed.txt');await page.locator('#cutBtn').click();await open('Destination');await page.locator('#pasteBtn').click();await row('renamed.txt').waitFor();await done();assert(!fs.existsSync(root+'/renamed.txt'));checks.push('cut paste');
 await home();await row('README.md').locator('button').filter({hasText:'Propriétés'}).click();await page.locator('#properties').waitFor({state:'visible'});assert.match(await page.locator('#propertyList').textContent(),/UID \/ GID/);await page.getByRole('button',{name:'Fermer les propriétés'}).click();checks.push('file properties');
 await open('README.md');await page.locator('#content').fill('# Updated with Ctrl S');await page.locator('#content').press('Control+s');await page.getByText('Enregistré.',{exact:true}).waitFor();assert.strictEqual(fs.readFileSync(root+'/README.md','utf8'),'# Updated with Ctrl S');await page.getByRole('button',{name:'Fermer',exact:true}).click();checks.push('editor Ctrl S');
 await page.locator('#newFile').click();await page.locator('#promptValue').fill('drag.txt');await page.locator('#promptForm').getByRole('button',{name:'Confirmer'}).click();await row('drag.txt').waitFor();await done();
 await row('drag.txt').dragTo(row('Destination'));await until(async()=>(await page.locator('#operationSummary').textContent()).startsWith('Déplacement'));await done();assert(fs.existsSync(root+'/Destination/drag.txt'));checks.push('internal drag drop');
 await page.locator('#gridView').click();await page.locator('#grid').waitFor({state:'visible'});assert.strictEqual(await page.locator('#tableWrap').isVisible(),false);checks.push('grid view');
 await page.screenshot({path:'/tmp/fm020-desktop.png',fullPage:true});await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/tmp/fm020-mobile.png',fullPage:true});assert.strictEqual(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);checks.push('mobile viewport no overflow');
 assert.deepStrictEqual(errors,[]);checks.push('no JavaScript runtime errors');console.log(JSON.stringify({status:'PASS',browser:'Chromium',count:checks.length,checks},null,2));
 }catch(e){if(browser){const pages=browser.contexts()[0]?.pages();if(pages?.[0])await pages[0].screenshot({path:'/tmp/fm020-failure.png',fullPage:true});}throw e;}
 finally{if(browser)await browser.close();server.kill();fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exit(1)});
