# Validation 0.2.0 — 30 octobre 2026

Exécution réelle : Linux, PHP 8.3.6, Symfony 7.4, Chromium headless (Playwright 1.51.1 pour le test navigateur). Pas d’exécution native sous Windows ; PHP 8.2 et PHP 8.4 prévus dans le workflow, non exécutés ici.

| Suite | Résultat |
|---|---|
| Moteur PHPUnit | 38 tests, 78 assertions — PASS |
| API HTTP réelle | 31 contrôles — PASS |
| Setup CLI | 5 contrôles — PASS |
| Parcours navigateur | 17 contrôles — PASS |
| Inspection visuelle | Desktop 1440 px et mobile 390 px — réalisée |
| Syntaxe PHP/JavaScript | PASS |

Le navigateur a exercé connexion, fichiers cachés, arbre extensible, sélection multiple, copie groupée, conflits sans écrasement, duplication récursive, corbeille et restauration de dossier non vide, menu contextuel de renommage, couper/coller, propriétés, Ctrl+S, glisser-déposer interne et vue grille. Aucun débordement horizontal du viewport mobile ni erreur JavaScript constaté dans ce parcours.
Une régression découverte pendant ces essais (cases à cocher restant désactivées après une mutation) a été corrigée ; le parcours navigateur vérifie leur réutilisation après les opérations.
Les tests ne constituent pas une certification d’accessibilité ni une validation exhaustive de toutes les combinaisons de navigateurs, Windows, NTFS, coupures système ou disques pleins. L’intégration daemon, les jobs et l’isolation multi-tenant restent hors périmètre.

Preuves machine dans `validation/`. Les captures de test n’utilisent que des données temporaires et ne sont pas incluses dans l’archive.
