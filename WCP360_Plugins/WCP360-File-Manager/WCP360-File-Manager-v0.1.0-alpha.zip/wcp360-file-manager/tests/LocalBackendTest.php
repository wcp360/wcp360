<?php
declare(strict_types=1);
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\DataProvider;
use Wcp360\FileManager\Contract\{Identity,FileError};
use Wcp360\FileManager\Infrastructure\LocalBackend;
final class LocalBackendTest extends TestCase
{
    private string $base; private LocalBackend $backend; private Identity $id;
    protected function setUp(): void
    {
        $this->base=sys_get_temp_dir().'/fm-test-'.bin2hex(random_bytes(8));
        mkdir($this->base);mkdir($this->base.'/root');mkdir($this->base.'/state');mkdir($this->base.'/root-other');
        $this->backend=new LocalBackend($this->base.'/root',$this->base.'/state','alice');$this->id=new Identity('standalone','alice',true);
    }
    protected function tearDown(): void { $this->remove($this->base); }
    private function remove(string $p): void { if(is_link($p)||!is_dir($p)){unlink($p);return;}foreach(scandir($p) as $n){if($n!=='.'&&$n!=='..')$this->remove($p.'/'.$n);}rmdir($p); }
    private function runOp(string $op,array $a=[]): array { return $this->backend->execute($this->id,$op,$a); }
    private function denied(string $code,callable $call): void
    { try{$call();self::fail('Expected '.$code);}catch(FileError $e){self::assertSame($code,$e->errorCode);} }
    public function testCreateSaveConflictAndDownload(): void
    {
        $created=$this->runOp('create',['path'=>'hello.txt','content'=>'bonjour']);
        $read=$this->runOp('read',['path'=>'hello.txt']);self::assertSame('bonjour',$read['content']);
        $saved=$this->runOp('save',['path'=>'hello.txt','content'=>'salut','revision'=>$created['revision']]);
        self::assertNotSame($created['revision'],$saved['revision']);
        $this->denied('CONCURRENCY_CONFLICT',fn()=>$this->runOp('save',['path'=>'hello.txt','content'=>'perdu','revision'=>$created['revision']]));
        self::assertSame('salut',$this->runOp('download',['path'=>'hello.txt'])['content']);
    }
    public static function badPaths(): array {return array_map(fn($p)=>[$p],['../root-other/secret.txt','/etc/passwd','a/../../x','a//b','./a',"x\0.txt",'a\\b','php://filter','a/','a/../b']);}
    #[DataProvider('badPaths')]
    public function testInvalidPaths(string $path): void { $this->denied('INVALID_PATH',fn()=>$this->runOp('create',['path'=>$path,'content'=>''])); }
    public function testSiblingPrefixAndSymlinks(): void
    {
        file_put_contents($this->base.'/root-other/secret.txt','secret');
        symlink($this->base.'/root-other',$this->base.'/root/escape');
        $this->denied('UNSAFE_ENTRY',fn()=>$this->runOp('read',['path'=>'escape/secret.txt']));
        $this->denied('UNSAFE_ENTRY',fn()=>$this->runOp('create',['path'=>'escape/new.txt','content'=>'']));
        self::assertSame('blocked',$this->runOp('list',['path'=>''])['items'][0]['kind']);
    }
    public function testDanglingSymlink(): void
    {symlink($this->base.'/absent',$this->base.'/root/link.txt');$this->denied('UNSAFE_ENTRY',fn()=>$this->runOp('create',['path'=>'link.txt','content'=>'attack']));}
    public function testHardlinks(): void
    {file_put_contents($this->base.'/root-other/private.txt','secret');link($this->base.'/root-other/private.txt',$this->base.'/root/link.txt');$this->denied('UNSAFE_ENTRY',fn()=>$this->runOp('read',['path'=>'link.txt']));}
    public function testTenantAndSubjectAndReadonly(): void
    {
        foreach([new Identity('other','alice',true),new Identity('standalone','bob',true)] as $id){$this->denied('ACCESS_DENIED',fn()=>$this->backend->execute($id,'list',['path'=>'']));}
        $this->denied('READ_ONLY',fn()=>$this->backend->execute(new Identity('standalone','alice',false),'mkdir',['path'=>'x']));
        self::assertSame(0,$this->backend->execute(new Identity('standalone','alice',false),'list',['path'=>''])['total']);
    }
    public function testRenameTrashRestoreCollision(): void
    {
        $this->runOp('mkdir',['path'=>'docs']);$c=$this->runOp('create',['path'=>'a.txt','content'=>'hello']);
        $this->runOp('rename',['path'=>'a.txt','destination'=>'docs/b.txt']);
        $t=$this->runOp('trash',['path'=>'docs/b.txt','revision'=>$c['revision']]);
        self::assertCount(1,$this->runOp('trash_list')['items']);
        $this->runOp('create',['path'=>'docs/b.txt','content'=>'new']);
        $this->denied('ALREADY_EXISTS',fn()=>$this->runOp('restore',['id'=>$t['id']]));
        $this->runOp('rename',['path'=>'docs/b.txt','destination'=>'docs/new.txt']);
        $this->runOp('restore',['id'=>$t['id']]);self::assertSame('hello',$this->runOp('read',['path'=>'docs/b.txt'])['content']);
        self::assertCount(0,$this->runOp('trash_list')['items']);
    }
    public function testEmptyDirectoryRestore(): void
    {$this->runOp('mkdir',['path'=>'x']);$t=$this->runOp('trash',['path'=>'x']);$this->runOp('restore',['id'=>$t['id']]);self::assertDirectoryExists($this->base.'/root/x');}
    public function testRejectNonEmptyDirectoryAndRoot(): void
    {
        $this->runOp('mkdir',['path'=>'x']);$this->runOp('create',['path'=>'x/a.txt','content'=>'']);
        $this->denied('DIRECTORY_NOT_EMPTY',fn()=>$this->runOp('trash',['path'=>'x']));
        $this->denied('ROOT_PROTECTED',fn()=>$this->runOp('trash',['path'=>'']));
        $this->denied('INVALID_PATH',fn()=>$this->runOp('rename',['path'=>'x','destination'=>'x/nested']));
    }
    public function testNoOverwriteAndMissingParent(): void
    {
        $this->runOp('create',['path'=>'a.txt','content'=>'a']);
        $this->denied('ALREADY_EXISTS',fn()=>$this->runOp('upload',['path'=>'a.txt','content'=>'b']));
        $this->denied('NOT_FOUND',fn()=>$this->runOp('create',['path'=>'missing/a.txt','content'=>'a']));
    }
    public function testTextAndUploadLimits(): void
    {
        $this->denied('FILE_TOO_LARGE',fn()=>$this->runOp('create',['path'=>'a.txt','content'=>str_repeat('x',1048577)]));
        $this->denied('NOT_TEXT',fn()=>$this->runOp('create',['path'=>'a.txt','content'=>"\0"]));
        $this->denied('NOT_EDITABLE',fn()=>$this->runOp('create',['path'=>'a.exe','content'=>'x']));
        $this->denied('FILE_TOO_LARGE',fn()=>$this->runOp('upload',['path'=>'a.bin','content'=>str_repeat('x',LocalBackend::MAX_FILE+1)]));
        $this->runOp('upload',['path'=>'a.bin','content'=>"\0\xff"]);self::assertSame("\0\xff",$this->runOp('download',['path'=>'a.bin'])['content']);
    }
    public function testDotfiles(): void
    {$this->runOp('create',['path'=>'.env','content'=>'APP=demo']);self::assertSame('APP=demo',$this->runOp('read',['path'=>'.env'])['content']);}
    public function testPaginationAndSearch(): void
    {for($i=0;$i<105;$i++)file_put_contents($this->base.'/root/doc'.$i.'.txt','');$l=$this->runOp('list',['path'=>'','page'=>2]);self::assertSame(105,$l['total']);self::assertCount(5,$l['items']);self::assertSame(1,$this->runOp('list',['path'=>'','query'=>'doc104'])['total']);}
    public function testCorbeilleIdentifierTraversal(): void
    {$this->denied('INVALID_INPUT',fn()=>$this->runOp('restore',['id'=>'../../root']));}
    public function testNestedStateRejected(): void
    {$this->expectException(RuntimeException::class);new LocalBackend($this->base.'/root',$this->base.'/root','alice');}
}
