# Validation — paquet local XAMPP 0.1.1 alpha

Cible du paquet : PHP 8.2+ pour le test autonome ; PHP 8.4 demeure la cible WCP360. Le runtime effectivement testé ici est PHP 8.3.6 sous Linux. Windows natif et cmd.exe ne sont pas disponibles : le double-clic BAT, les ACL NTFS et le comportement réel du filesystem Windows restent à confirmer sur le PC utilisateur.

- 34 tests PHPUnit / 55 assertions : PASS, y compris chemins Windows normalisés, préfixes voisins et noms réservés.
- 20 tests HTTP : PASS. Réexécutés après installation du vendor de production sans dépendances de développement : PASS.
- 5 contrôles de setup : PASS (installation, vérification du mot de passe généré, refus d’écraser, chemin avec espaces, déplacement du dossier).
- Diagnostic du lanceur via PHP : PASS sous Linux.
- Syntaxe PHP et JavaScript : PASS.
- Composer validate strict et check-platform-reqs : PASS sur PHP 8.3.6, sans ignore-platform-req.
- PHP 8.2 et PHP 8.4 natifs : NON EXÉCUTÉS ici. Résolution Composer avec platform.php=8.2.0.
- Navigateur / responsive : NON VALIDÉ, le navigateur de test n’est pas disponible.
- Windows : NON EXÉCUTÉ. Tests de chaînes de chemins ne valent pas validation de NTFS.

Les preuves se trouvent dans validation/. Le rapport 0.1.0 est conservé uniquement comme historique.

Changements : vendor runtime inclus avec licences tierces, lanceur Windows et diagnostic PHP, normalisation des séparateurs de chemins, refus des noms réservés Windows, configuration de stockage relative à son dossier pour rendre le paquet déplaçable, garde PHP 8.2+, refus Apache du dossier source pour éviter son exposition accidentelle.

Cette distribution est un test local, pas une release approuvée pour l’hébergement multi-tenant. Aucun code daemon ou shell d’administration n’est ajouté. Le BAT lance uniquement le setup CLI et le serveur PHP local explicitement sur 127.0.0.1.
