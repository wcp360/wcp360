"use strict";
const $=id=>document.getElementById(id);
let cwd='',page=1,total=0,trash=false,csrf='',canWrite=false,editing=null,baseline='',sequence=0,busy=false;
const notice=(msg)=>{$('notice').textContent=msg;};
async function api(op,data={},post=false){
 const options={headers:{Accept:'application/json'},credentials:'same-origin'};
 let url='/api/v1/files/'+op;
 if(post){options.method='POST';options.headers['X-CSRF-Token']=csrf;if(data instanceof FormData)options.body=data;else{options.headers['Content-Type']='application/json';options.body=JSON.stringify(data);}}
 else url+='?'+new URLSearchParams(data);
 const r=await fetch(url,options);
 if(r.redirected || !r.headers.get('content-type')?.includes('application/json'))throw new Error('Session expirée. Rechargez la page pour vous connecter.');
 const body=await r.json();if(!r.ok)throw new Error((body.error?.message||'Opération impossible.')+(body.request_id?' Réf. '+body.request_id:''));return body.data;
}
function button(text,handler){const b=document.createElement('button');b.textContent=text;b.onclick=()=>Promise.resolve().then(handler).catch(e=>notice(e.message));return b;}
function cell(tr,text){const td=document.createElement('td');td.textContent=text??'—';tr.append(td);return td;}
const size=n=>n===null?'—':n<1024?n+' o':n<1048576?(n/1024).toFixed(1)+' Kio':(n/1048576).toFixed(1)+' Mio';
const date=t=>t?new Date(t*1000).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'}):'—';
function breadcrumbs(){const n=$('breadcrumbs');n.replaceChildren(button('Mes fichiers',()=>navigate('')));let part='';for(const s of cwd.split('/').filter(Boolean)){const span=document.createElement('span');span.textContent='/';part+=(part?'/':'')+s;const path=part;n.append(span,button(s,()=>navigate(path)));}}
async function navigate(path){cwd=path;page=1;trash=false;$('search').value='';await load();}
async function load(){
 const seq=++sequence;notice('Chargement…');
 const data=await api(trash?'trash_list':'list',{path:cwd,page,query:$('search').value});if(seq!==sequence)return;
 total=data.total??data.items.length;$('rows').replaceChildren();$('title').textContent=trash?'Corbeille':'Mes fichiers';
 $('filesNav').classList.toggle('active',!trash);$('trashNav').classList.toggle('active',trash);
 $('breadcrumbs').hidden=trash;$('search').disabled=trash;document.querySelectorAll('.write').forEach(e=>e.hidden=!canWrite || (trash && e.id!=='save'));
 for(const item of data.items){const tr=document.createElement('tr');const name=cell(tr,'');
 if(trash){name.textContent=item.path;cell(tr,'—');cell(tr,date(item.deleted_at));cell(tr,'—');const actions=cell(tr,'');if(canWrite)actions.append(button('Restaurer',()=>mutate('restore',{id:item.id})));}
 else{const icon=document.createElement('span');icon.className='icon';icon.textContent=item.kind==='directory'?'▰':item.kind==='blocked'?'⊘':'≡';name.append(icon);
 name.append(button(item.name,()=>item.kind==='directory'?navigate(item.path):item.kind==='blocked'?notice('Lien ou fichier spécial : accès bloqué.'):openEditor(item.path)));
 cell(tr,size(item.size));cell(tr,date(item.mtime));cell(tr,item.mode);const actions=cell(tr,'');
 if(item.kind==='file')actions.append(button('Télécharger',()=>download(item.path)));
 if(canWrite && item.kind!=='blocked'){actions.append(button('Déplacer',()=>ask('Renommer ou déplacer','Chemin complet relatif à la racine.',item.path,d=>mutate('rename',{path:item.path,destination:d}))));
 actions.append(button('Corbeille',async()=>{if(!confirm('Mettre « '+item.name+' » à la corbeille ? Les dossiers doivent être vides.'))return;let revision;
 if(item.kind==='file'){// Obtain revision without putting downloaded bytes into DOM.
 const r=await fetch('/api/v1/files/download?'+new URLSearchParams({path:item.path}),{credentials:'same-origin'});
 if(!r.ok || r.redirected || !r.headers.get('content-type')?.includes('application/octet-stream'))throw new Error('Impossible de vérifier le fichier.');
 const bytes=await r.arrayBuffer();revision=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');}
 await mutate('trash',{path:item.path,...(revision?{revision}:{} )});}));}}
 $('rows').append(tr);}
 $('empty').hidden=data.items.length!==0;$('count').textContent=total+' élément'+(total>1?'s':'');
 $('page').textContent=trash?'':`Page ${page} / ${Math.max(1,Math.ceil(total/100))}`;$('prev').disabled=trash||page<=1;$('next').disabled=trash||page*100>=total;
 breadcrumbs();notice('');
}
async function mutate(op,input){if(busy)return;busy=true;try{await api(op,input,true);await load();notice('Opération effectuée.');}finally{busy=false;}}
async function openEditor(path){const data=await api('read',{path});editing=data;baseline=data.content;$('editorTitle').textContent=path;$('content').value=data.content;$('content').readOnly=!canWrite;$('editorStatus').textContent='UTF-8 · '+size(new TextEncoder().encode(data.content).length);$('editor').showModal();}
function dirty(){return editing && $('content').value!==baseline;}
$('editor').addEventListener('cancel',e=>{if(dirty()&&!confirm('Abandonner les modifications ?'))e.preventDefault();});
$('closeEditor').onclick=e=>{if(dirty()&&!confirm('Abandonner les modifications ?'))e.preventDefault();};
window.addEventListener('beforeunload',e=>{if($('editor').open&&dirty()){e.preventDefault();e.returnValue='';}});
$('save').onclick=async()=>{if(!editing)return;$('save').disabled=true;const content=$('content').value;try{const r=await api('save',{path:editing.path,content,revision:editing.revision},true);editing.revision=r.revision;baseline=content;$('editorStatus').textContent='Enregistré.';await load();}catch(e){$('editorStatus').textContent=e.message;}finally{$('save').disabled=false;}};
async function download(path){const r=await fetch('/api/v1/files/download?'+new URLSearchParams({path}),{credentials:'same-origin'});if(!r.ok || r.redirected || !r.headers.get('content-type')?.includes('application/octet-stream')){let msg='Téléchargement impossible.';try{msg=(await r.json()).error.message;}catch{}throw new Error(msg);}const url=URL.createObjectURL(await r.blob());const a=document.createElement('a');a.href=url;a.download=path.split('/').pop();a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
let promptHandler;
function ask(title,help,value,handler){$('promptTitle').textContent=title;$('promptHelp').textContent=help;$('promptValue').value=value;promptHandler=handler;$('prompt').showModal();$('promptValue').focus();}
$('cancelPrompt').onclick=()=>$('prompt').close();$('promptForm').onsubmit=async e=>{e.preventDefault();const value=$('promptValue').value;$('prompt').close();try{await promptHandler(value);}catch(error){notice(error.message);}};
const child=name=>(cwd?cwd+'/':'')+name;
$('newFile').onclick=()=>ask('Nouveau fichier','Exemple : notes.txt. Le fichier sera créé vide.','',name=>mutate('create',{path:child(name),content:''}));
$('newFolder').onclick=()=>ask('Nouveau dossier','Le dossier parent doit déjà exister.','',name=>mutate('mkdir',{path:child(name)}));
$('uploadBtn').onclick=()=>$('upload').click();$('upload').onchange=async()=>{const f=$('upload').files[0];if(!f)return;try{if(f.size>20971520)throw new Error('Import limité à 20 Mio.');const body=new FormData();body.append('file',f);body.append('path',child(f.name));await mutate('upload',body);}catch(e){notice(e.message);}finally{$('upload').value='';}};
$('filesNav').onclick=()=>{trash=false;page=1;load().catch(e=>notice(e.message));};$('trashNav').onclick=()=>{trash=true;load().catch(e=>notice(e.message));};
$('refresh').onclick=()=>load().catch(e=>notice(e.message));$('prev').onclick=()=>{page--;load().catch(e=>notice(e.message));};$('next').onclick=()=>{page++;load().catch(e=>notice(e.message));};
let searchTimer;$('search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{page=1;load().catch(e=>notice(e.message));},250);};
(async()=>{try{const s=await api('session');csrf=s.csrf;canWrite=s.can_write;$('user').textContent=s.user;$('logoutToken').value=s.logout_csrf;await load();}catch(e){notice(e.message);}})();
