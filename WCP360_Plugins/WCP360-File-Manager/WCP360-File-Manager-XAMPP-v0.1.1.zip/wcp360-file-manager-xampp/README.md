# Test Windows / XAMPP — 0.1.1 alpha

**Commencer par `LIRE-MOI-WINDOWS.txt`, puis double-cliquer `DEMARRER-WINDOWS.bat`.**

Ce paquet inclut vendor et accepte PHP 8.2+. La cible WCP360 reste PHP 8.4. Le launcher utilise le PHP de XAMPP sans Apache/MySQL, à http://127.0.0.1:8088/. Tester dans un nouveau dossier hors htdocs. Windows natif non exécuté ici.

---

# WCP360 File Manager — 0.1.0 alpha

Extension PHP 8.2+ / Symfony 7.4, avec application autonome et interface française responsive.
**Statut : version de développement. Intégration officielle WCP360 non effectuée.**

## Ce qui fonctionne

- Connexion Symfony, mot de passe haché, limitation des tentatives et déconnexion avec CSRF.
- Liste de fichiers, fil d’Ariane, recherche dans le dossier et pagination (100 éléments/page).
- Création de fichiers texte et dossiers ; renommage et déplacement sans écrasement.
- Éditeur UTF-8 (1 Mio maximum), avertissement avant fermeture et contrôle de révision SHA-256.
- Import multipart et téléchargement en pièce jointe (20 Mio maximum).
- Corbeille et restauration au chemin d’origine, sans écrasement. Dossiers vides uniquement.
- Permissions visibles ; rôle lecture seule pris en charge par le moteur et l’interface.
- API JSON, erreurs structurées, identifiants de requête, journal d’opérations JSONL.
- Moteur local derrière une interface remplaçable `FileBackend`.

## Installation autonome

Prérequis : PHP 8.2+, Composer 2, extensions PHP JSON, fileinfo, session, mbstring, XML/DOM (tests), tokenizer (tests).

```bash
composer install --no-interaction
php standalone/bin/setup.php
php -d upload_max_filesize=20M -d post_max_size=22M -S 127.0.0.1:8088 -t standalone/public standalone/public/index.php
```

Ouvrir http://127.0.0.1:8088 ; utiliser l’identifiant choisi et le mot de passe aléatoire affiché une seule fois par l’installation. Le conserver dans un gestionnaire de mots de passe.
Le serveur PHP intégré est réservé à l’usage local. Pour une exposition réseau : PHP-FPM, HTTPS, configuration de proxy fiable et limites de requêtes (voir `docs/DEPLOYMENT.md`).

L’installation crée `standalone/var/config.php`, `files/` et `state/`. Elle refuse d’écraser une configuration existante. Ne jamais committer ni publier `var/`.
Le compte PHP doit posséder exclusivement ces répertoires privés. **Ne pas choisir un répertoire de sites web exécutables, un home partagé, ou une arborescence modifiable par des tenants.**

## Deux usages

| Mode | État | Stockage |
|---|---|---|
| Autonome mono-utilisateur | Implémenté, tests locaux décrits dans `docs/VALIDATION.md` | Répertoire privé géré exclusivement par ce processus |
| Extension dans une application Symfony | Points d’intégration et configuration fournis | Identité et backend injectés par l’application hôte |
| WCP360 / daemon wcpd / multi-tenant | À contractualiser et implémenter | Exécuteur Linux isolé requis ; adaptateur désactivé par défaut |

`docs/INTEGRATION-WCP360.md` précise les contrats à valider. Ce paquet ne migre pas le backend de WCP360 et ne change aucune baseline. `UnavailableWcpBackend` répond 503 et n’exécute aucune action.

## Vérification

Le ZIP inclut les dépendances de fonctionnement seulement. Pour exécuter PHPUnit en développement, lancer auparavant `composer install` afin de réinstaller les dépendances de test.

```bash
composer validate --strict
composer lint
composer test
python3 tests/http_smoke.py
composer audit
```

Le test HTTP utilise une application temporaire et ne touche jamais aux données existantes. Workflow GitHub Actions PHP 8.4 inclus. `composer.lock` fixe les dépendances de cette distribution autonome ; les mises à jour doivent être testées puis refigées.

## Limites explicites

Pas d’extraction ZIP, de compression, de chmod/chown, de liens symboliques, de commande shell, de copie récursive, de suppression définitive depuis l’interface, de sélection multiple, de multi-utilisateur autonome, de quotas applicatifs ni de sauvegarde automatique dans cette version.
La corbeille n’est pas une sauvegarde et n’a pas de purge automatique. Surveillance du disque et quota système nécessaires. Une arborescence est limitée à 10 000 entrées par dossier ; la consultation de la corbeille à 1 000 éléments.
Les fichiers PHP et `.env` peuvent être édités comme texte **uniquement dans cet espace privé**. Ils ne sont jamais exécutés par le module.

Consulter `docs/SECURITY.md` avant de choisir le backend local. Une vérification `realpath()` n’est pas une isolation Linux et ne résout pas les courses TOCTOU face à un processus hostile.
