<?php
declare(strict_types=1);
namespace Wcp360\FileManager\Standalone;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
final class LoginController
{
    #[Route('/login',name:'fm_login',methods:['GET','POST'])]
    public function login(CsrfTokenManagerInterface $csrf, AuthenticationUtils $auth): Response
    {
        $token=htmlspecialchars($csrf->getToken('authenticate')->getValue(),ENT_QUOTES,'UTF-8');
        $error=$auth->getLastAuthenticationError() ? '<p role="alert">Connexion refusée. Vérifiez vos identifiants.</p>':'';
        $html=<<<HTML
<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connexion · File Manager</title><body><main><h1>WCP360 File Manager</h1><p>Votre espace de fichiers privé.</p>$error<form method="post" action="/login"><p><label>Identifiant <input name="_username" required autocomplete="username"></label></p><p><label>Mot de passe <input type="password" name="_password" required autocomplete="current-password"></label></p><input type="hidden" name="_csrf_token" value="$token"><button>Se connecter</button></form></main></body></html>
HTML;
        return new Response($html,200,['Cache-Control'=>'no-store','X-Content-Type-Options'=>'nosniff','Content-Security-Policy'=>"default-src 'none'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"]);
    }
    #[Route('/logout',name:'fm_logout',methods:['POST'])]
    public function logout(): never { throw new \LogicException('Handled by Symfony firewall'); }
    #[Route('/',name:'fm_root',methods:['GET'])]
    public function root(): Response { return new \Symfony\Component\HttpFoundation\RedirectResponse('/file-manager'); }
}
